#!/bin/bash
# Script to display date and calendar for March 2022

echo "Date: $(date)"
echo "Calendar for March 2022:"
cal 3 2022
