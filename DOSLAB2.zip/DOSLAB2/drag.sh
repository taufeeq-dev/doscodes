#!/bin/bash
# Script to display command-line arguments

if [ $# -lt 2 ]; then
    echo "Usage: $0 <arg1> <arg2> ..."
    exit 1
fi

echo "Total arguments: $#"
echo "First argument: $1"
echo "Second argument: $2"

# Display all arguments
echo "All arguments: $@"
