#!/bin/bash
# Script to merge, sort, and display contents of a.txt, b.txt, c.txt

cat a.txt b.txt c.txt | sort > result
cat result
