#!/bin/bash
# Script to display system information

echo "Login Name: $(whoami)"
echo "System Name: $(uname -s)"
echo "Shell Type: $SHELL"
echo "Current Working Directory: $(pwd)"
echo "Files in Current Directory:"
ls
