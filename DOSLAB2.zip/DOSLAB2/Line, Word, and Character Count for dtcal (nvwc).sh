#!/bin/bash
# Script to display counts for dtcal

file="dtcal"
if [ -f $file ]; then
    echo "Filename: $file"
    echo "Line count: $(wc -l < $file)"
    echo "Word count: $(wc -w < $file)"
    echo "Char count: $(wc -c < $file)"
else
    echo "File $file does not exist."
fi
