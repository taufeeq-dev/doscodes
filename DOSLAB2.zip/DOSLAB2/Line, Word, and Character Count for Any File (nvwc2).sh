#!/bin/bash
# Script to display counts for a given file

if [ $# -ne 1 ]; then
    echo "Usage: $0 <filename>"
    exit 1
fi

file=$1
if [ -f $file ]; then
    echo "Filename: $file"
    echo "Line count: $(wc -l < $file)"
    echo "Word count: $(wc -w < $file)"
    echo "Char count: $(wc -c < $file)"
else
    echo "File $file does not exist."
fi
